import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class DifferentDropDowns {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//WebDriver gcDriver = OpenBrowser.createDriver("firefox");
         WebDriver gcDriver = OpenBrowser.createDriver("Chrome");
         gcDriver.manage().window().maximize();
        String url="https://www.seleniumeasy.com/test/";
        gcDriver.get(url);
        Thread.sleep(2000);
        
        String popUpId="at-cv-lightbox-close";
        WebElement popUp = gcDriver.findElement(By.id(popUpId));
        popUp.click();
        
        String inputFormsXpath = "//a[@class='dropdown-toggle']";
        WebElement inputForms = gcDriver.findElement(By.xpath(inputFormsXpath));
        inputForms.click();
        
        String jqueryXpath = "//a[text()='JQuery Select dropdown']";
        WebElement jqueryDropdown = gcDriver.findElement(By.xpath(jqueryXpath));
        jqueryDropdown.click();
        
        WebElement searchDD = gcDriver.findElement(By.id("country"));
        Select selectDD = new Select(searchDD);
        selectDD.selectByVisibleText("Australia");
        
        WebElement state = gcDriver.findElement(By.cssSelector("input.select2-search__field"));
        state.click();
        state.sendKeys("Cali");
        
        WebElement stateOption1 = gcDriver.findElement (By.xpath("//li[text()='California']"));
        stateOption1.click();
        
        WebElement state2 = gcDriver.findElement(By.cssSelector("input.select2-search__field"));
        state2.click();
        state2.sendKeys("del");
        
        WebElement stateOption2 = gcDriver.findElement(By.xpath("//li[text()='Delaware']"));
        stateOption2.click();
        
        
        //WebElement state3 = gcDriver.findElement(By.xpath("//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']"));
        //System.out.println(disabledDD.isEnabled());
        //state3.click();
        //state3.sendKeys("Puerto");
        
        //WebElement state3 = gcDriver.findElement(By.xpath("//span[@id='select2-q6vc-container']/following-sibling::span"));
        //state3.click();
        
        WebElement disableDropdown = gcDriver.findElement(By.xpath("//select[@class='js-example-disabled-results select2-hidden-accessible']"));
        Select selectDiasbleState = new Select(disableDropdown);
        selectDiasbleState.selectByVisibleText("Puerto Rico");
		/*
		 * List<WebElement> enableElement = selectDiasbleState.getAllSelectedOptions();
		 * for(WebElement item:enableElement) { System.out.println(item.getText()); }
		 */
        //System.out.println();
      
        String categoryDropdown="files";
	    Select dropdown = new Select(gcDriver.findElement(By.id(categoryDropdown)));  
	    dropdown.selectByVisibleText("Ruby");
        
        
      	}

}
