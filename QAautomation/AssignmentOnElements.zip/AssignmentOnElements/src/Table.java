import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Table {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		WebDriver gcDriver = OpenBrowser.createDriver("Chrome");
		//WebDriver firefoxDriver = OpenBrowser.createDriver("Firefox");
        gcDriver.manage().window().maximize();
       String url="https://www.seleniumeasy.com/test/";
       gcDriver.get(url);
       Thread.sleep(1000);
       
       String popUpId="at-cv-lightbox-close";
       WebElement popUp = gcDriver.findElement(By.id(popUpId));
       popUp.click();
       
       String inputFormsXpath = "//a[@class='dropdown-toggle']";
       WebElement inputForms = gcDriver.findElement(By.xpath(inputFormsXpath));
       inputForms.click();
       
       String inputFormSubmitXpath="//ul[@class='dropdown-menu']//a[text()='Input Form Submit']";
       WebElement inputFormSubmit = gcDriver.findElement(By.xpath(inputFormSubmitXpath));
	   inputFormSubmit.click();
	   
	   String tableXpath="//a[text()='Table']";
	   WebElement table = gcDriver.findElement(By.xpath(tableXpath));
	   table.click();
	   
	   String tableDataSearchXpath = "//ul[@id='treemenu']//a[text()='Table Data Search']";
	   WebElement tableDataSearch = gcDriver.findElement(By.xpath(tableDataSearchXpath));
	   tableDataSearch.click();
	   
	   String inputFieldOfTableId = "task-table-filter";
	   WebElement inputFieldOfTable = gcDriver.findElement(By.id(inputFieldOfTableId));
	   inputFieldOfTable.click();
	   inputFieldOfTable.clear();
	   inputFieldOfTable.sendKeys("john");
	   
	   String getRowsXpath="//table[@id='task-table']/tbody/tr";
	   List<WebElement> getRows = gcDriver.findElements(By.xpath(getRowsXpath));
	   for(WebElement row:getRows) {
		   List<WebElement> tds = row.findElements(By.tagName("td"));
		   String rowText = tds.get(2).getText();
		   System.out.println("Row value is "+rowText);
	   }
	  
	}

}
