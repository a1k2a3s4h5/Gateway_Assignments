import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
public class PracticeOne {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
        WebDriver firefoxDriver = OpenBrowser.createDriver("firefox");
        
        String url="https://www.seleniumeasy.com/test/";
        firefoxDriver.get(url);
        Thread.sleep(2000);
        
        String popUpId="at-cv-lightbox-close";
        WebElement popUp = firefoxDriver.findElement(By.id(popUpId));
        popUp.click();
        
        String inputFormsXpath = "//a[@class='dropdown-toggle']";
        WebElement inputForms = firefoxDriver.findElement(By.xpath(inputFormsXpath));
        inputForms.click();
        
        String inputFormSubmitXpath="//ul[@class='dropdown-menu']//a[text()='Input Form Submit']";
        WebElement inputFormSubmit = firefoxDriver.findElement(By.xpath(inputFormSubmitXpath));
	    inputFormSubmit.click();
	    
	    String first_name="first_name";
	    WebElement firstName = firefoxDriver.findElement(By.name(first_name));
	    firstName.click();
	    firstName.clear();
	    firstName.sendKeys("Akash");
	    
	    String last_name="last_name";
	    WebElement lastName = firefoxDriver.findElement(By.name(last_name));
	    lastName.click();
	    lastName.clear();
	    lastName.sendKeys("Patel");
	    
	    String emailName = "email";
	    WebElement email = firefoxDriver.findElement(By.name(emailName));
	    email.click();
	    email.clear();
	    email.sendKeys("akashpatel1927.9687@gmail.com");
	    
	    String phoneName="phone";
	    WebElement phone = firefoxDriver.findElement(By.name(phoneName));
	    phone.click();
	    phone.clear();
	    phone.sendKeys("9687963179");
	    
	    String addressName="address";
	    WebElement address = firefoxDriver.findElement(By.name(addressName));
	    address.click();
	    address.clear();
	    address.sendKeys("1242,Motapara,Patel Fadiyu,Vejalpur");
	    
	    String cityName="city";
	    WebElement city = firefoxDriver.findElement(By.name(cityName));
	    city.click();
	    city.clear();
	    city.sendKeys("GODHRA");
	    
	    String dropdownXpath="//div[@class='input-group']//select[@name='state']";
	    Select dropdown = new Select(firefoxDriver.findElement(By.xpath(dropdownXpath)));  
	    dropdown.selectByVisibleText("Arizona");
	    //List<WebElement> elementCount = dropdown.getOptions();
	    //System.out.println(elementCount);
	    //for(WebElement option : elementCount) {
	    	//System.out.println(option.getText());
	    //}
	    
	    String zipName="zip";
	    WebElement zipCode = firefoxDriver.findElement(By.name(zipName));
	    zipCode.click();
	    zipCode.clear();
	    zipCode.sendKeys("389340");
	    
	    String websiteName="website";
	    WebElement website = firefoxDriver.findElement(By.name(websiteName));
	    website.click();
	    website.clear();
	    website.sendKeys("www.google.com");
	    
	    String radioButtonName="hosting";
	    WebElement radioButton = firefoxDriver.findElement(By.name(radioButtonName));
	    radioButton.click();
	 	    
	    String descriptionName="comment";
	    WebElement description = firefoxDriver.findElement(By.name(descriptionName));
	    description.click();
	    description.clear();
	    description.sendKeys("www.google.com");
	    
	    String submitButtonCssSelector = "button.btn btn-default";
	    WebElement submitButton = firefoxDriver.findElement(By.cssSelector(submitButtonCssSelector));
	    submitButton.click();
	    
	    
	    
	}

}
