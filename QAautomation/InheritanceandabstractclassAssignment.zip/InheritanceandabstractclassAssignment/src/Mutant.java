
public interface Mutant {
     public static void mutantDetails(String name , String ability , String planet) {
    	 System.out.println("Mutant name is "+ name);
    	 System.out.println("Mutant's ability is "+ability);
    	 System.out.println("Mutant's planet is "+planet);
     }
     void personalityDetails(String personality);
}
