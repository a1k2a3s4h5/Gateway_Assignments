import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.ss.usermodel.Sheet;

import org.apache.poi.ss.usermodel.Workbook;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
public class PracticeOne {

	public static void main(String[] args) throws InterruptedException, FileNotFoundException {
		// TODO Auto-generated method stub
        WebDriver firefoxDriver = OpenBrowser.createDriver("Chrome");
        firefoxDriver.manage().window().maximize();
        
        String url="https://www.seleniumeasy.com/test/";
        firefoxDriver.get(url);
        Thread.sleep(2000);
        
        String popUpId="at-cv-lightbox-close";
        WebElement popUp = firefoxDriver.findElement(By.id(popUpId));
        popUp.click();
        
        String inputFormsXpath = "//a[@class='dropdown-toggle']";
        WebElement inputForms = firefoxDriver.findElement(By.xpath(inputFormsXpath));
        inputForms.click();
        
        String inputFormSubmitXpath="//ul[@class='dropdown-menu']//a[text()='Input Form Submit']";
        WebElement inputFormSubmit = firefoxDriver.findElement(By.xpath(inputFormSubmitXpath));
	    inputFormSubmit.click();
	    
	    String fileName="inputform.xlsx";
		String sheetName="Akash";
		File file = new File("C:\\Users\\Vishva Patel\\Desktop\\MenualTestingQA\\Assignment"+"\\"+"inputform.xlsx");
		FileInputStream inputStream = new FileInputStream(file);
		Workbook workbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if(fileExtensionName.equals(".xlsx")){

		    //If it is xlsx file then create object of XSSFWorkbook class

		    try {
				workbook = new XSSFWorkbook(inputStream);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		    }
		Sheet sheet = workbook.getSheet(sheetName);
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		System.out.println("Row Count is " + rowCount);
  
		for (int i = 1; i < rowCount+1; i++) {
			Row row = sheet.getRow(i);
			int cellNumber = 0;
		    //row.getLastCellNum();
			String first_name="first_name";
		    WebElement firstName = firefoxDriver.findElement(By.name(first_name));
		    firstName.click();
		    firstName.clear();
		    firstName.sendKeys(row.getCell(cellNumber).getStringCellValue());
		    
		    String last_name="last_name";
		    WebElement lastName = firefoxDriver.findElement(By.name(last_name));
		    lastName.click();
		    lastName.clear();
		    lastName.sendKeys(row.getCell(cellNumber+1).getStringCellValue());
		    
		    String emailName = "email";
		    WebElement email = firefoxDriver.findElement(By.name(emailName));
		    email.click();
		    email.clear();
		    email.sendKeys(row.getCell(cellNumber+2).getStringCellValue());    
		
		    String phoneName="phone";
		    WebElement phone = firefoxDriver.findElement(By.name(phoneName));
		    phone.click();
		    phone.clear();
		    phone.sendKeys(String.valueOf((long)row.getCell(cellNumber+3).getNumericCellValue()));
		
		    String addressName="address";
		    WebElement address = firefoxDriver.findElement(By.name(addressName));
		    address.click();
		    address.clear();
		    address.sendKeys(row.getCell(cellNumber+4).getStringCellValue());
		
		    String cityName="city";
		    WebElement city = firefoxDriver.findElement(By.name(cityName));
		    city.click();
		    city.clear();
		    city.sendKeys(row.getCell(cellNumber+5).getStringCellValue());
		
		    String dropdownXpath="//div[@class='input-group']//select[@name='state']";
		    Select dropdown = new Select(firefoxDriver.findElement(By.xpath(dropdownXpath)));  
		    dropdown.selectByVisibleText(row.getCell(cellNumber+6).getStringCellValue());

		    String zipName="zip";
		    WebElement zipCode = firefoxDriver.findElement(By.name(zipName));
		    zipCode.click();
		    zipCode.clear();
		    zipCode.sendKeys(String.valueOf((long)row.getCell(cellNumber+7).getNumericCellValue()));
		
		    String websiteName="website";
		    WebElement website = firefoxDriver.findElement(By.name(websiteName));
		    website.click();
		    website.clear();
		    website.sendKeys(row.getCell(cellNumber+8).getStringCellValue());
		    
		    boolean yesOrNo = row.getCell(cellNumber+9).getBooleanCellValue();
		    if(yesOrNo) {
		    	String radioButtonName="hosting";
			    WebElement radioButtonYes = firefoxDriver.findElement(By.name(radioButtonName));
			    radioButtonYes.click();
		    }
		    else {
		    	String redioButtonXpath ="//input[@value='no']";
		    	WebElement radioButtonNo = firefoxDriver.findElement(By.xpath(redioButtonXpath));
			    radioButtonNo.click();
		    }
		    
		    
		    String descriptionName="comment";
		    WebElement description = firefoxDriver.findElement(By.name(descriptionName));
		    description.click();
		    description.clear();
		    description.sendKeys(row.getCell(cellNumber+10).getStringCellValue());
		    
		    String submitButtonCssSelector = "button.btn.btn-default";
		    //Thread.sleep(4000);
		    WebElement submitButton = firefoxDriver.findElement(By.cssSelector(submitButtonCssSelector));
		    submitButton.click();
		
		    System.out.println("Currently "+ i + " number pf row is varifying.");
		}
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    //List<WebElement> elementCount = dropdown.getOptions();
	    //System.out.println(elementCount);
	    //for(WebElement option : elementCount) {
	    	//System.out.println(option.getText());
	    //}
	    
	    
	    
	    
	    
	    
	 	    
	    
	    
	    
	    
	}

}
