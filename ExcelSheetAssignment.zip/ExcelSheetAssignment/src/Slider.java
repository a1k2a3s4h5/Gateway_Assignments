import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Slider {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		  WebDriver gcDriver = OpenBrowser.createDriver("Chrome"); // WebDriverWait //
		  WebDriverWait wait=new WebDriverWait(gcDriver, 10); 
		  gcDriver.manage().window().maximize();
		  String url = "https://www.seleniumeasy.com/test/"; gcDriver.get(url);
			/*
			 * gcDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			 * gcDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			 */
		  String popUpId = "at-cv-lightbox-close"; 
		  WebElement popUp = gcDriver.findElement(By.id(popUpId)); 
		  wait.until(ExpectedConditions.visibilityOf(popUp));
		  popUp.click();
		  
		  String progressBarXpath = "//a[contains(text(),'Progress Bars')]"; WebElement
		  progressBar = gcDriver.findElement(By.xpath(progressBarXpath));
		  progressBar.click();
		  
		  String slidersXpath =
		  "//ul[@class='dropdown-menu']//a[text()='Drag & Drop Sliders']"; WebElement
		  sliders = gcDriver.findElement(By.xpath(slidersXpath)); sliders.click();
		 
		  Thread.sleep(5000);
		  String defaultValue10Xpath = "//div[@id='slider1']//input[@type='range']";
		  WebElement defaultValue10 = gcDriver.findElement(By.xpath(defaultValue10Xpath));
		  //Dimension sliderSize = defaultValue10.getSize();
		  int sliderWidth = defaultValue10.getSize().getWidth();
		  int xCoord = defaultValue10.getLocation().getX();
		  System.out.println(sliderWidth+" " +xCoord);
		  Actions action = new Actions(gcDriver);
		  //action.moveToElement(defaultValue10).click().moveByOffset(0, 0)
		  //action.moveToElement(defaultValue10).click().dragAndDropBy(defaultValue10,-210, 0).build().perform();
		  action.moveToElement(defaultValue10).clickAndHold().moveByOffset(30, 0).release().perform();
		  System.out.println(sliderWidth+ " " +defaultValue10.getLocation().getX());
	}

}
