import java.util.concurrent.TimeUnit;
//import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.ElementNotSelectableException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Exceptionsandwait {
	public static void main(String[] args) throws InterruptedException {
		 String url="https://www.seleniumeasy.com/test/";

		 	WebDriver gcDriver=OpenBrowser.createDriver("Firefox");
			gcDriver.manage().window().maximize();
			gcDriver.get(url);
			gcDriver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
			WebDriverWait wait = new WebDriverWait(gcDriver, 10);
			try {
			String popupId="at-cv-lightbox-close";
			WebElement popupClose=gcDriver.findElement(By.id(popupId));
			popupClose.click();
			
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			
			try {
				gcDriver.findElement(By.id("Anything"));
			}
			catch(NoSuchElementException e) {
				System.out.println(e.getMessage());
			}
			
			try {
			String inputFormsPath="//a[@class='dropdown-toggle']";
			WebElement inputForm=gcDriver.findElement(By.xpath(inputFormsPath));
			inputForm.click();
			}
			catch(Exception e) {
			System.out.println(e.getMessage());
			}
			try {
			String inputFormsSubmitPath="//ul[@class='dropdown-menu']//a[text()='Input Form Submit']";
			WebElement inputFormSubmit=gcDriver.findElement(By.xpath(inputFormsSubmitPath));
			inputFormSubmit.click();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			try {
				
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("anything"))).click();
			} 
			catch (TimeoutException t) {
				System.out.println("Time Out Exception: Not found presence of element.");
			}
			
			String firstName="first_name";
			WebElement fName=gcDriver.findElement(By.name(firstName));
			fName.click();
			fName.clear();
			fName.sendKeys("Akash");
			
			String lastName="last_name";
			WebElement lName=gcDriver.findElement(By.name(lastName));
			lName.click();
			lName.clear();
			lName.sendKeys("Patel");
			
			
			String emailId="email";
			WebElement email=gcDriver.findElement(By.name(emailId));
			email.click();
			email.clear();
			email.sendKeys("test123@mail.com");
			
			
			String phoneNo="phone";
			WebElement phone=gcDriver.findElement(By.name(phoneNo));
			phone.click();
			phone.clear();
			phone.sendKeys("7813267323");
			
			String Address="address";
			WebElement address=gcDriver.findElement(By.name(Address));
			address.click();
			address.clear();
			address.sendKeys("anything");
			
			try {
				gcDriver.switchTo().alert().accept();
				} 
			catch (NoAlertPresentException e) {
				System.out.println("Not found any alert over here..");
				}
			
				String City="city";
				WebElement city=gcDriver.findElement(By.name(City));
				city.click();
				city.clear();
				city.sendKeys("abc");
	
			//gcDriver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
			String inputFormsPath="//a[@class='dropdown-toggle']";
			WebElement inputForm=gcDriver.findElement(By.xpath(inputFormsPath));
			inputForm.click();
			
			
			String jquerySelectDD="//ul[@class='dropdown-menu']//a[text()='JQuery Select dropdown']";
			WebElement inputFormSubmit=gcDriver.findElement(By.xpath(jquerySelectDD));
			inputFormSubmit.click();
			
			String countryId="country";
			WebElement countryDD=gcDriver.findElement(By.id(countryId));
			Select selectDD=new Select(countryDD);
			selectDD.selectByIndex(6);
			
			
			WebElement stateDD=gcDriver.findElement(By.cssSelector("input.select2-search__field"));
			stateDD.click();
			stateDD.sendKeys("North");
			
			
			String state1="//li[text()='North Dakota']";
			WebElement stateselect1=gcDriver.findElement(By.xpath(state1));
			stateselect1.click();
			
			
			stateDD.click();
			stateDD.sendKeys("alabama");
			String state2="//li[text()='Alabama']";
			WebElement stateselect2=gcDriver.findElement(By.xpath(state2));
			stateselect2.click();
			
			
			try {
		    WebElement disabledDD = gcDriver.findElement(By.xpath("//select[@class='js-example-disabled-results select2-hidden-accessible']"));
		    Select disabledStateDD = new Select(disabledDD);
		    disabledStateDD.selectByVisibleText("Guam");			
		    }
			catch(ElementNotSelectableException e) {
				System.out.println(e.getMessage());
			}
			
			String fileDD="files";
			Select categoryDd=new Select(gcDriver.findElement(By.id(fileDD)));
			categoryDd.selectByVisibleText("Java");
}
}
