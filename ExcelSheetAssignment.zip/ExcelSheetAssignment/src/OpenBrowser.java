import java.util.ArrayList;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class OpenBrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           WebDriver driver = createDriver("Chrome");
           driver.get("https://www.google.com");
           String current_window = driver.getWindowHandle();
           System.out.println(current_window);
           JavascriptExecutor Js = (JavascriptExecutor)driver;
           Js.executeScript("window.open();");
           Set<String> s = driver.getWindowHandles();
           //ArrayList<String> list =new ArrayList<String>();
           //for(String handle:s) {
        	//  list.add(handle);
           //}
           //String next_window = list.get(list.size()-1);
          // driver.switchTo().window(next_window);
           System.out.println(s);
           driver.get("https://www.youtube.com");
           //String pageSource = driver.getPageSource();
           //System.out.println(pageSource);
           //driver = createDriver("Firefox");
           
           
           /*driver.get("https://www.google.com");
           driver.navigate().to("https://www.youtube.com");
           driver.navigate().back();
           driver.navigate().forward();
           driver.navigate().refresh();
           driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");*/
           //driver = createDriver("Edge");
           //driver.get("https://www.google.com");
	}
	
	static WebDriver createDriver(String browserName) {
		WebDriver driver = null;
		String gcPath = "drivers/chromedriver.exe";
		if(browserName.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vishva Patel\\Downloads\\Webdriver\\chromedriver.exe");
		    driver = new ChromeDriver();
		}
		else if(browserName.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\Vishva Patel\\Desktop\\QAautomation\\Driver\\geckodriver.exe");
		    driver = new FirefoxDriver();
		}
		else if(browserName.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver", "C:\\Users\\Vishva Patel\\Desktop\\QAautomation\\Driver\\msedgedriver.exe");
		    driver = new EdgeDriver();
		}
		return driver;
	}

}
