import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProgressBarAndAlert {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		WebDriver gcDriver = OpenBrowser.createDriver("Chrome");
		WebDriverWait wait=new WebDriverWait(gcDriver, 10);
        gcDriver.manage().window().maximize();
       String url="https://www.seleniumeasy.com/test/";
       gcDriver.get(url);
       Thread.sleep(2000);
       
       String popUpId="at-cv-lightbox-close";
       WebElement popUp = gcDriver.findElement(By.id(popUpId));
       popUp.click();
       
       String pBarAndSlidersXpath = "//ul[@id='treemenu']//a[text()='Alerts & Modals']";
       WebElement pBarAndSliders = gcDriver.findElement(By.xpath(pBarAndSlidersXpath));
       pBarAndSliders.click();
       
       //gcDriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
       String progressBarModelXpath = "//ul[@id='treemenu']//a[text()='Progress Bar Modal']";
       WebElement progressBarModel = gcDriver.findElement(By.xpath(progressBarModelXpath));
       progressBarModel.click();
 
       String buttonCselctor ="button.btn.btn-warning";
       WebElement button = gcDriver.findElement(By.cssSelector(buttonCselctor));
       button.click();
       
       wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("progress-bar")));
       WebElement progressBarValue = gcDriver.findElement(By.xpath("//h3[text()='Hello Mr. Alert !']"));
       System.out.println(progressBarValue.getText());
       wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("progress-bar")));
       
       
	}

}
