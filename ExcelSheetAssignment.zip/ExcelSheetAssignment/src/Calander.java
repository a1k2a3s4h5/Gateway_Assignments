import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Calander {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		WebDriver gcDriver = OpenBrowser.createDriver("Chrome"); // WebDriverWait
		// wait=new WebDriverWait(gcDriver, 10);
		gcDriver.manage().window().maximize();
		String url = "https://www.seleniumeasy.com/test/";
		gcDriver.get(url);
		Thread.sleep(2000);

		String popUpId = "at-cv-lightbox-close";
		WebElement popUp = gcDriver.findElement(By.id(popUpId));
		popUp.click();

		String datePickersXpath = "//a[contains(text(),'Date pickers')]";
		WebElement datePickers = gcDriver.findElement(By.xpath(datePickersXpath));
		datePickers.click();

		String jquertDatePickersXpath = "//ul[@class='dropdown-menu']//a[text()='JQuery Date Picker']";
		WebElement jqueryDatePickers = gcDriver.findElement(By.xpath(jquertDatePickersXpath));
		jqueryDatePickers.click();

		String fromXpath = "//input[@id='from']";
		WebElement from = gcDriver.findElement(By.xpath(fromXpath));
		from.click();
		
		LocalDate date = LocalDate.now();
		int todaysDate = date.getDayOfMonth();
		String currentMonth = String.valueOf(date.getMonth());
		String currentMonthLower = currentMonth.toLowerCase();
		String lowerLettersOfCurrentMonth = currentMonthLower.substring(1,3);
		String currentMonthCamel = currentMonthLower.substring(0,1).toUpperCase().concat(lowerLettersOfCurrentMonth);
		//int currentMonthIndex = currentMonth - 1;
		
		LocalDate nextSevenDate = LocalDate.now().plusDays(40);
		int nextSevenDayDate = nextSevenDate.getDayOfMonth();
		String nextMonth = String.valueOf(nextSevenDate.getMonth());

		//System.out.println(nextMonth);
		String nextMonthLower = nextMonth.toLowerCase();
		String lowerLettersOfNextMonth = nextMonthLower.substring(1,3);
		String nextMonthCamel = nextMonthLower.substring(0,1).toUpperCase().concat(lowerLettersOfNextMonth);
		System.out.println(nextMonthCamel);
		
		String selectMonthXpath = "//select[@class='ui-datepicker-month']";
	    WebElement month = gcDriver.findElement(By.xpath(selectMonthXpath)); 
	    Select selectMonth = new Select(month);
	    
	    selectMonth.selectByVisibleText(currentMonthCamel);
	    System.out.println(currentMonthCamel);
	    
		String todaysXpath = "//a[text()='"+todaysDate+"']";
		WebElement todayDate = gcDriver.findElement(By.xpath(todaysXpath));
		todayDate.click();
		
		
		String toXpath = "//input[@id='to']";
		WebElement to = gcDriver.findElement(By.xpath(toXpath));
		to.click();
		
		String selectToMonthXpath = "//select[@class='ui-datepicker-month']";
	    WebElement ToMonth = gcDriver.findElement(By.xpath(selectToMonthXpath)); Select
		selectToMonth = new Select(ToMonth); 
	    selectToMonth.selectByVisibleText(nextMonthCamel);
	    
		String nextSevenDayXpath = "//a[text()='"+nextSevenDayDate+"']";
		WebElement nextSevenDate1 = gcDriver.findElement(By.xpath(nextSevenDayXpath));
		nextSevenDate1.click();
		
		
		
		

	}

}


/*
 * String pattern = "MM/dd/yyyy"; SimpleDateFormat simpleDateFormat = new
 * SimpleDateFormat(pattern); String date = simpleDateFormat.format(new Date());
 * System.out.println(date); fromDate.sendKeys(date); LocalDate date =
 * LocalDate.now(); System.out.println("date: "+date.getDayOfMonth());
 */		

/*
 * 
 * 
 * String dayXpath = "//a[text()='14']"; WebElement day =
 * gcDriver.findElement(By.xpath(dayXpath)); day.click();
 */

//String toXpath = "//label[@for='from']/following-sibling::input[2]";

//toDate.sendKeys("03/08/2021");

/*
 * String selectToMonthXpath = "//select[@class='ui-datepicker-month']";
 * WebElement toMonth = gcDriver.findElement(By.xpath(selectToMonthXpath));
 * Select selectToMonth = new Select(toMonth);7                                        6y              bh y7b
 * selectToMonth.selectByVisibleText("Mar");
 * 
 * String toDayXpath = "//a[text()='1']"; WebElement toDay =
 * gcDriver.findElement(By.xpath(toDayXpath)); toDay.click();
 */

// LocalDate myDateObj = LocalDate.now();
// System.out.println(myDateObj);
/*
 * String pattern = "MM/dd/yyyy"; SimpleDateFormat simpleDateFormat = new
 * SimpleDateFormat(pattern); String date = simpleDateFormat.format(new Date());
 * System.out.println(date);
 */
